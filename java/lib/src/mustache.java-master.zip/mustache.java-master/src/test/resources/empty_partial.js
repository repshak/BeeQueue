var partial_context = {
  foo: 1
};
