var partial_context = {
  "title": "Welcome",
  "template_partial_2": {
    "again": "Goodbye"
  }
}
