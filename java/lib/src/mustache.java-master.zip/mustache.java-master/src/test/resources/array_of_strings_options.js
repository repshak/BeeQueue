var array_of_strings_options = {array_of_strings_options: ['hello', 'world']};
