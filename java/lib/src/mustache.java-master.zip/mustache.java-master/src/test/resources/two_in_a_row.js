var two_in_a_row = {
  name: "Joe",
  greeting: "Welcome"
};
