var null_string = {
  name: "Elise",
  glytch: true,
  binary: false,
  value: null,
  numeric: function() {
    return NaN;
  }
};
