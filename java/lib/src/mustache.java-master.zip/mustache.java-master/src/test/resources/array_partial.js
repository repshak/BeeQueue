var partial_context = { 
  partial: {
    array: ['1', '2', '3', '4']
  }
};