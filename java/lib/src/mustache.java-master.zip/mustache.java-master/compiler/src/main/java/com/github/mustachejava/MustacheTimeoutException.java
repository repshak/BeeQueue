package com.github.mustachejava;

/**
 * Special exception just for timeouts.
 */
public class MustacheTimeoutException extends MustacheException {
}
